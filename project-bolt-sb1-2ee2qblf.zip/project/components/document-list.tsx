'use client';

import { useState } from 'react';
import { Document, supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Eye, Download, Trash2, FileText, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

interface DocumentListProps {
  documents: Document[];
  dossierId: string;
  onDocumentDeleted?: (docId: string) => void;
}

export function DocumentList({ documents, dossierId, onDocumentDeleted }: DocumentListProps) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set());

  const handleDelete = async () => {
    if (!selectedDoc) return;

    const docId = selectedDoc.id;
    setDeletingIds(prev => new Set(prev).add(docId));
    setDeleteDialogOpen(false);
    setSelectedDoc(null);

    if (onDocumentDeleted) {
      onDocumentDeleted(docId);
    }

    try {
      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', docId);

      if (error) throw error;

      toast.success('Document supprimé');
    } catch (error: any) {
      toast.error(`Erreur: ${error.message}`);
      console.error('Delete error:', error);
      setDeletingIds(prev => {
        const next = new Set(prev);
        next.delete(docId);
        return next;
      });
    }
  };

  const visibleDocuments = documents.filter(doc => !deletingIds.has(doc.id));

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) {
      return <ImageIcon className="h-4 w-4" />;
    }
    return <FileText className="h-4 w-4" />;
  };

  if (visibleDocuments.length === 0) {
    return (
      <div className="border-2 border-dashed rounded-lg p-8 text-center text-muted-foreground">
        <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
        <p>Aucun document</p>
        <p className="text-sm">Ajoutez vos fichiers ci-dessus</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-2">
        <h3 className="font-medium text-sm mb-3">Documents ({visibleDocuments.length})</h3>
        {visibleDocuments.map((doc) => (
          <div
            key={doc.id}
            className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/50 transition-colors"
          >
            <div className="flex items-center gap-3 flex-1 min-w-0">
              {getFileIcon(doc.mime_type)}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{doc.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatBytes(doc.size_bytes)} •{' '}
                  {formatDistanceToNow(new Date(doc.created_at), {
                    addSuffix: true,
                    locale: fr,
                  })}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  setSelectedDoc(doc);
                  setPreviewDialogOpen(true);
                }}
              >
                <Eye className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                asChild
              >
                <a href={doc.url} download={doc.name} target="_blank" rel="noopener noreferrer">
                  <Download className="h-4 w-4" />
                </a>
              </Button>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => {
                  setSelectedDoc(doc);
                  setDeleteDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer &quot;{selectedDoc?.name}&quot; ? Cette action est
              irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Supprimer</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>{selectedDoc?.name}</DialogTitle>
          </DialogHeader>
          <div className="overflow-auto">
            {selectedDoc?.mime_type === 'application/pdf' ? (
              <object
                data={selectedDoc.url}
                type="application/pdf"
                className="w-full h-[70vh]"
              >
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(selectedDoc.url)}&embedded=true`}
                  className="w-full h-[70vh] border-0"
                  title={selectedDoc.name}
                />
              </object>
            ) : selectedDoc?.mime_type.startsWith('image/') ? (
              <img
                src={selectedDoc.url}
                alt={selectedDoc.name}
                className="max-w-full h-auto mx-auto"
              />
            ) : (
              <p className="text-center text-muted-foreground">
                Prévisualisation non disponible
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

'use client';

import { useState, useTransition } from 'react';
import { LibraryDocument, supabase } from '@/lib/supabase';
import { uploadLibraryDocument } from '@/lib/actions/library';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Library, Upload, Eye, Download, Trash2, FileText, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

interface LibraryDialogProps {
  initialDocuments: LibraryDocument[];
}

const CATEGORIES = ['Alphera', 'Immatriculation', 'Contrats internes', 'Documents internes'] as const;
type Category = typeof CATEGORIES[number];

export function LibraryDialog({ initialDocuments }: LibraryDialogProps) {
  const [open, setOpen] = useState(false);
  const [documents, setDocuments] = useState<LibraryDocument[]>(initialDocuments);
  const [isPending, startTransition] = useTransition();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<LibraryDocument | null>(null);
  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set());
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Tous'>('Tous');
  const [uploadCategory, setUploadCategory] = useState<Category>('Alphera');

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('category', uploadCategory);

    startTransition(async () => {
      try {
        const newDoc = await uploadLibraryDocument(formData);
        setDocuments((prev) => [newDoc, ...prev]);
        toast.success('Document ajouté à la bibliothèque');
        e.target.value = '';
      } catch (error: any) {
        toast.error(`Erreur: ${error.message}`);
      }
    });
  };

  const handleDelete = async () => {
    if (!selectedDoc) return;

    const docId = selectedDoc.id;
    setDeletingIds((prev) => new Set(prev).add(docId));
    setDeleteDialogOpen(false);
    setSelectedDoc(null);
    setDocuments((prev) => prev.filter((doc) => doc.id !== docId));

    try {
      const { error } = await supabase
        .from('library_documents')
        .delete()
        .eq('id', docId);

      if (error) throw error;

      toast.success('Document supprimé de la bibliothèque');
    } catch (error: any) {
      toast.error(`Erreur: ${error.message}`);
      console.error('Delete error:', error);
      setDeletingIds((prev) => {
        const next = new Set(prev);
        next.delete(docId);
        return next;
      });
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) {
      return <ImageIcon className="h-4 w-4" />;
    }
    return <FileText className="h-4 w-4" />;
  };

  const filteredDocuments = documents.filter((doc) => {
    if (selectedCategory === 'Tous') return true;
    return doc.category === selectedCategory;
  });

  const visibleDocuments = filteredDocuments.filter((doc) => !deletingIds.has(doc.id));

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="default">
            <Library className="h-4 w-4 mr-2" />
            Bibliothèque de documents
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-3xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>Bibliothèque de documents</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Catégorie :</label>
                <select
                  value={uploadCategory}
                  onChange={(e) => setUploadCategory(e.target.value as Category)}
                  className="border rounded-md px-3 py-1.5 text-sm bg-background"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <label htmlFor="library-upload" className="cursor-pointer">
                <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-blue-400 hover:bg-blue-50/50 transition-colors">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm font-medium">Cliquez pour ajouter un document</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PDF, images et autres formats supportés
                  </p>
                </div>
                <input
                  id="library-upload"
                  type="file"
                  className="hidden"
                  onChange={handleUpload}
                  disabled={isPending}
                />
              </label>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant={selectedCategory === 'Tous' ? 'default' : 'outline'}
                    onClick={() => setSelectedCategory('Tous')}
                  >
                    Tous ({documents.filter(d => !deletingIds.has(d.id)).length})
                  </Button>
                  {CATEGORIES.map((cat) => {
                    const count = documents.filter(
                      (d) => d.category === cat && !deletingIds.has(d.id)
                    ).length;
                    return (
                      <Button
                        key={cat}
                        size="sm"
                        variant={selectedCategory === cat ? 'default' : 'outline'}
                        onClick={() => setSelectedCategory(cat)}
                      >
                        {cat} ({count})
                      </Button>
                    );
                  })}
                </div>
              </div>
              {visibleDocuments.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Library className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>
                    {selectedCategory === 'Tous'
                      ? 'Aucun document dans la bibliothèque'
                      : `Aucun document dans la catégorie ${selectedCategory}`}
                  </p>
                  <p className="text-sm mt-1">
                    {selectedCategory === 'Tous'
                      ? 'Ajoutez vos premiers documents ci-dessus'
                      : 'Changez de catégorie ou ajoutez un document'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2 max-h-[50vh] overflow-y-auto">
                  {visibleDocuments.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        {getFileIcon(doc.mime_type)}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium truncate">{doc.name}</p>
                            <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary whitespace-nowrap">
                              {doc.category}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {formatBytes(doc.size_bytes)} •{' '}
                            {formatDistanceToNow(new Date(doc.created_at), {
                              addSuffix: true,
                              locale: fr,
                            })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setSelectedDoc(doc);
                            setPreviewDialogOpen(true);
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" asChild>
                          <a href={doc.url} download={doc.name} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4" />
                          </a>
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => {
                            setSelectedDoc(doc);
                            setDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer &quot;{selectedDoc?.name}&quot; de la bibliothèque ?
              Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Supprimer</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>{selectedDoc?.name}</DialogTitle>
          </DialogHeader>
          <div className="overflow-auto">
            {selectedDoc?.mime_type === 'application/pdf' ? (
              <object
                data={selectedDoc.url}
                type="application/pdf"
                className="w-full h-[70vh]"
              >
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(selectedDoc.url)}&embedded=true`}
                  className="w-full h-[70vh] border-0"
                  title={selectedDoc.name}
                />
              </object>
            ) : selectedDoc?.mime_type.startsWith('image/') ? (
              <img
                src={selectedDoc.url}
                alt={selectedDoc.name}
                className="max-w-full h-auto mx-auto"
              />
            ) : (
              <p className="text-center text-muted-foreground">
                Prévisualisation non disponible
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

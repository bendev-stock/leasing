'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { ChecklistItem, ChecklistKey, supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface ChecklistCardProps {
  dossierId: string;
  items: ChecklistItem[];
}

export function ChecklistCard({ dossierId, items }: ChecklistCardProps) {
  const [optimisticItems, setOptimisticItems] = useState(items);

  useEffect(() => {
    setOptimisticItems(items);
  }, [items]);

  const handleToggle = async (key: ChecklistKey, currentChecked: boolean) => {
    const newChecked = !currentChecked;

    setOptimisticItems((prev) =>
      prev.map((item) =>
        item.key === key ? { ...item, checked: newChecked } : item
      )
    );

    try {
      const { error } = await supabase
        .from('checklist_items')
        .update({ checked: newChecked })
        .eq('dossier_id', dossierId)
        .eq('key', key);

      if (error) throw error;
    } catch (error: any) {
      setOptimisticItems(items);
      toast.error('Erreur lors de la mise à jour');
      console.error(error);
    }
  };

  const checkedCount = optimisticItems.filter((item) => item.checked).length;
  const totalCount = optimisticItems.length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Checklist du dossier</CardTitle>
        <CardDescription>
          {checkedCount} sur {totalCount} tâches complétées
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {optimisticItems.map((item) => (
            <div key={item.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-accent/50 transition-colors">
              <Checkbox
                id={item.id}
                checked={item.checked}
                onCheckedChange={() => handleToggle(item.key, item.checked)}
              />
              <label
                htmlFor={item.id}
                className={`text-sm flex-1 cursor-pointer ${
                  item.checked ? 'line-through text-muted-foreground' : ''
                }`}
              >
                {item.label}
              </label>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

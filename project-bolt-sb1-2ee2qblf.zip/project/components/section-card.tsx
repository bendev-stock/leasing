'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { DossierSection, Document, SECTION_TITLES } from '@/lib/supabase';
import { DocumentList } from '@/components/document-list';
import { SectionNotes } from '@/components/section-notes';
import { Uploader } from '@/components/uploader';

interface SectionCardProps {
  dossierId: string;
  section: DossierSection;
  documents: Document[];
  noteContent: string;
}

export function SectionCard({ dossierId, section, documents, noteContent }: SectionCardProps) {
  const [sectionDocs, setSectionDocs] = useState<Document[]>(
    documents.filter((doc) => doc.section === section)
  );

  useEffect(() => {
    setSectionDocs(documents.filter((doc) => doc.section === section));
  }, [documents, section]);

  const handleDocumentAdded = (newDoc: Document) => {
    console.log('Adding document to section:', newDoc);
    setSectionDocs((prev) => {
      const exists = prev.some(doc => doc.id === newDoc.id);
      if (exists) {
        return prev;
      }
      return [...prev, newDoc];
    });
  };

  const handleDocumentDeleted = (docId: string) => {
    console.log('Deleting document from section:', docId);
    setSectionDocs((prev) => prev.filter((doc) => doc.id !== docId));
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-xl">{SECTION_TITLES[section]}</CardTitle>
        <CardDescription>Gérez les documents et notes pour cette section</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-4">
            <Uploader dossierId={dossierId} section={section} onDocumentAdded={handleDocumentAdded} />
            <DocumentList documents={sectionDocs} dossierId={dossierId} onDocumentDeleted={handleDocumentDeleted} />
          </div>
          <SectionNotes
            dossierId={dossierId}
            section={section}
            initialContent={noteContent}
          />
        </div>
      </CardContent>
    </Card>
  );
}

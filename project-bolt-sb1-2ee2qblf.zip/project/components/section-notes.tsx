'use client';

import { useState, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { DossierSection } from '@/lib/supabase';
import { updateSectionNote } from '@/lib/actions/dossier';
import { toast } from 'sonner';
import { Check } from 'lucide-react';

interface SectionNotesProps {
  dossierId: string;
  section: DossierSection;
  initialContent: string;
  onNoteUpdate?: (section: DossierSection, content: string) => void;
}

export function SectionNotes({ dossierId, section, initialContent, onNoteUpdate }: SectionNotesProps) {
  const [content, setContent] = useState(initialContent);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setContent(initialContent);
  }, [initialContent]);

  const handleBlur = async () => {
    if (content === initialContent) return;

    try {
      setSaving(true);
      await updateSectionNote(dossierId, section, content);
      if (onNoteUpdate) {
        onNoteUpdate(section, content);
      }
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde');
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm">Notes</h3>
        {saved && (
          <Badge variant="outline" className="gap-1">
            <Check className="h-3 w-3" />
            Enregistré
          </Badge>
        )}
      </div>
      <Textarea
        placeholder="Ajoutez vos notes ici..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        onBlur={handleBlur}
        className="min-h-[150px] resize-none"
        disabled={saving}
      />
    </div>
  );
}

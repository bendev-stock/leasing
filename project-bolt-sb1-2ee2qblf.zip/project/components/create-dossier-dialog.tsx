'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus } from 'lucide-react';
import { createDossier } from '@/lib/actions/dossier';
import { toast } from 'sonner';

export function CreateDossierDialog() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const firstName = formData.get('firstName') as string;
    const lastName = formData.get('lastName') as string;
    const vehicleModel = formData.get('vehicleModel') as string;
    const email = formData.get('email') as string;
    const phone = formData.get('phone') as string;

    if (!firstName.trim() || !lastName.trim()) {
      toast.error('Le prénom et le nom sont requis');
      setLoading(false);
      return;
    }

    try {
      const dossier = await createDossier({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        vehicleModel: vehicleModel.trim() || undefined,
        email: email.trim() || undefined,
        phone: phone.trim() || undefined,
      });

      toast.success('Dossier créé');
      setOpen(false);
      router.push(`/dossiers/${dossier.id}`);
    } catch (error) {
      toast.error('Erreur lors de la création du dossier');
      console.error(error);
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="gap-2">
          <Plus className="h-5 w-5" />
          Créer un nouveau dossier
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Nouveau dossier</DialogTitle>
            <DialogDescription>
              Remplissez les informations du client pour créer un nouveau dossier.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="firstName">
                Prénom <span className="text-red-500">*</span>
              </Label>
              <Input
                id="firstName"
                name="firstName"
                placeholder="Jean"
                required
                autoFocus
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lastName">
                Nom <span className="text-red-500">*</span>
              </Label>
              <Input
                id="lastName"
                name="lastName"
                placeholder="Dupont"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="vehicleModel">Véhicule</Label>
              <Input
                id="vehicleModel"
                name="vehicleModel"
                placeholder="Tesla Model 3"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Mail</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="jean.dupont@example.com"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Téléphone</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                placeholder="+33 6 12 34 56 78"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={loading}
            >
              Annuler
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Création...' : 'Créer le dossier'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

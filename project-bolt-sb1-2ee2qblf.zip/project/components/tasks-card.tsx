'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Task, supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Plus, Trash2 } from 'lucide-react';

interface TasksCardProps {
  dossierId: string;
  initialTasks: Task[];
}

export function TasksCard({ dossierId, initialTasks }: TasksCardProps) {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleAddTask = async () => {
    if (!newTaskDescription.trim()) {
      toast.error('Veuillez entrer une description');
      return;
    }

    setIsAdding(true);

    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert({
          dossier_id: dossierId,
          description: newTaskDescription.trim(),
          completed: false,
        })
        .select()
        .single();

      if (error) throw error;

      setTasks((prev) => [...prev, data]);
      setNewTaskDescription('');
      toast.success('Tâche ajoutée');
    } catch (error: any) {
      toast.error(`Erreur: ${error.message}`);
      console.error(error);
    } finally {
      setIsAdding(false);
    }
  };

  const handleToggleTask = async (taskId: string, currentCompleted: boolean) => {
    const newCompleted = !currentCompleted;

    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId ? { ...task, completed: newCompleted } : task
      )
    );

    try {
      const { error } = await supabase
        .from('tasks')
        .update({ completed: newCompleted })
        .eq('id', taskId);

      if (error) throw error;
    } catch (error: any) {
      setTasks((prev) =>
        prev.map((task) =>
          task.id === taskId ? { ...task, completed: currentCompleted } : task
        )
      );
      toast.error('Erreur lors de la mise à jour');
      console.error(error);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== taskId));

    try {
      const { error } = await supabase.from('tasks').delete().eq('id', taskId);

      if (error) throw error;

      toast.success('Tâche supprimée');
    } catch (error: any) {
      toast.error('Erreur lors de la suppression');
      console.error(error);
    }
  };

  const pendingCount = tasks.filter((task) => !task.completed).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Tâches</CardTitle>
        <CardDescription>
          {pendingCount} tâche{pendingCount !== 1 ? 's' : ''} à faire
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Nouvelle tâche..."
              value={newTaskDescription}
              onChange={(e) => setNewTaskDescription(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !isAdding) {
                  handleAddTask();
                }
              }}
              disabled={isAdding}
            />
            <Button onClick={handleAddTask} disabled={isAdding} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            {tasks.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                Aucune tâche
              </p>
            ) : (
              tasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-3 p-2 rounded-md hover:bg-accent/50 transition-colors group"
                >
                  <Checkbox
                    id={task.id}
                    checked={task.completed}
                    onCheckedChange={() => handleToggleTask(task.id, task.completed)}
                  />
                  <label
                    htmlFor={task.id}
                    className={`text-sm flex-1 cursor-pointer ${
                      task.completed ? 'line-through text-muted-foreground' : ''
                    }`}
                  >
                    {task.description}
                  </label>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => handleDeleteTask(task.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

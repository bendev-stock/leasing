'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, Loader2 } from 'lucide-react';
import { DossierSection, Document } from '@/lib/supabase';
import { uploadDocument } from '@/lib/actions/dossier';
import { toast } from 'sonner';

interface UploaderProps {
  dossierId: string;
  section: DossierSection;
  onDocumentAdded?: (doc: Document) => void;
}

export function Uploader({ dossierId, section, onDocumentAdded }: UploaderProps) {
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    const uploadedCount = [];

    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('dossierId', dossierId);
      formData.append('section', section);

      try {
        const newDoc = await uploadDocument(formData);
        console.log('Document uploaded:', newDoc);

        if (!newDoc) {
          throw new Error('Document upload returned null');
        }

        uploadedCount.push(file);

        if (onDocumentAdded) {
          onDocumentAdded(newDoc);
        }
      } catch (error: any) {
        console.error('Upload error:', error);
        toast.error(`Erreur: ${error.message || 'Upload failed'}`);
      }
    }

    if (uploadedCount.length > 0) {
      toast.success(`${uploadedCount.length} document(s) ajouté(s)`);
    }

    e.target.value = '';
    setUploading(false);
  };

  return (
    <div>
      <input
        type="file"
        id={`file-upload-${section}`}
        className="hidden"
        accept="application/pdf,image/png,image/jpeg"
        multiple
        onChange={handleFileChange}
        disabled={uploading}
      />
      <label htmlFor={`file-upload-${section}`}>
        <Button
          type="button"
          variant="outline"
          className="w-full"
          disabled={uploading}
          asChild
        >
          <span className="cursor-pointer">
            {uploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Upload en cours...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Ajouter des documents
              </>
            )}
          </span>
        </Button>
      </label>
      <p className="text-xs text-muted-foreground mt-2">
        PDF, JPG ou PNG - Max 50 Mo par fichier
      </p>
    </div>
  );
}

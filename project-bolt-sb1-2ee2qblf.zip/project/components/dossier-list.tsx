'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { User, Car, Mail, Phone, ChevronRight, CheckSquare } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { STATUS_LABELS, STATUS_COLORS, DossierStatus, Dossier, Task } from '@/lib/supabase';

interface DossierWithTasks extends Dossier {
  pendingTasks: Task[];
}

interface DossierListProps {
  dossiers: DossierWithTasks[];
}

const ALL_STATUSES: DossierStatus[] = [
  'DOCUMENTS_DEMANDES',
  'DOCUMENTS_RECUS',
  'LEASING_EN_COURS',
  'SOLVABILITE_APPROUVEE',
  'DOSSIER_REFUSE',
  'SANS_SUITE',
  'FINALISE',
];

export function DossierList({ dossiers }: DossierListProps) {
  const [selectedStatus, setSelectedStatus] = useState<DossierStatus | 'ALL'>('ALL');

  const filteredDossiers = selectedStatus === 'ALL'
    ? dossiers
    : dossiers.filter(d => d.status === selectedStatus);

  const getStatusCount = (status: DossierStatus | 'ALL') => {
    if (status === 'ALL') return dossiers.length;
    return dossiers.filter(d => d.status === status).length;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedStatus === 'ALL' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedStatus('ALL')}
            className="transition-all"
          >
            Tous ({getStatusCount('ALL')})
          </Button>
          {ALL_STATUSES.map((status) => {
            const count = getStatusCount(status);
            if (count === 0) return null;
            const statusColor = STATUS_COLORS[status];
            const statusLabel = STATUS_LABELS[status];

            return (
              <Button
                key={status}
                variant={selectedStatus === status ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedStatus(status)}
                className={`transition-all ${
                  selectedStatus === status
                    ? ''
                    : `hover:${statusColor.bg} hover:${statusColor.text}`
                }`}
              >
                {statusLabel} ({count})
              </Button>
            );
          })}
        </div>
      </div>

      <h2 className="text-2xl font-semibold mb-4">
        Dossiers ({filteredDossiers.length})
      </h2>

      <div className="grid gap-4">
        {filteredDossiers.map((dossier) => {
          const statusColor = STATUS_COLORS[dossier.status as DossierStatus];
          const statusLabel = STATUS_LABELS[dossier.status as DossierStatus];

          return (
            <Link key={dossier.id} href={`/dossiers/${dossier.id}`}>
              <Card className="hover:shadow-lg transition-all hover:border-blue-300 cursor-pointer group">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-6">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-3 flex-wrap">
                        <User className="h-5 w-5 text-blue-600" />
                        <h3 className="text-xl font-semibold group-hover:text-blue-600 transition-colors">
                          {dossier.first_name} {dossier.last_name}
                        </h3>
                        <Badge
                          className={`${statusColor.bg} ${statusColor.text} ${statusColor.border} border font-medium`}
                          variant="outline"
                        >
                          {statusLabel}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {dossier.vehicle_model && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Car className="h-4 w-4" />
                            <span>{dossier.vehicle_model}</span>
                          </div>
                        )}
                        {dossier.email && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Mail className="h-4 w-4" />
                            <span className="truncate">{dossier.email}</span>
                          </div>
                        )}
                        {dossier.phone && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Phone className="h-4 w-4" />
                            <span>{dossier.phone}</span>
                          </div>
                        )}
                      </div>
                      <div className="mt-3 text-xs text-muted-foreground">
                        Modifié {formatDistanceToNow(new Date(dossier.updated_at), {
                          addSuffix: true,
                          locale: fr,
                        })}
                      </div>
                    </div>

                    {dossier.pendingTasks.length > 0 ? (
                      <div className="w-64 flex-shrink-0 space-y-2 border-l pl-6">
                        <div className="flex items-center gap-2 text-xs font-medium text-amber-700">
                          <CheckSquare className="h-4 w-4" />
                          <span>{dossier.pendingTasks.length} tâche{dossier.pendingTasks.length > 1 ? 's' : ''} à faire</span>
                        </div>
                        <div className="space-y-1">
                          {dossier.pendingTasks.slice(0, 3).map((task) => (
                            <div key={task.id} className="text-xs text-muted-foreground flex items-start gap-1.5">
                              <span className="text-amber-600 mt-0.5">•</span>
                              <span className="flex-1">{task.description}</span>
                            </div>
                          ))}
                          {dossier.pendingTasks.length > 3 && (
                            <div className="text-xs text-muted-foreground italic pl-3">
                              +{dossier.pendingTasks.length - 3} autre{dossier.pendingTasks.length - 3 > 1 ? 's' : ''}
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <ChevronRight className="h-6 w-6 text-muted-foreground group-hover:text-blue-600 group-hover:translate-x-1 transition-all flex-shrink-0" />
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EditDossierDialog } from '@/components/edit-dossier-dialog';
import { DossierStatusSelector } from '@/components/dossier-status-selector';
import { User, Mail, Phone, Car, ArrowLeft } from 'lucide-react';
import { Dossier, DossierStatus } from '@/lib/supabase';
import { useRouter } from 'next/navigation';

interface DossierHeaderProps {
  initialDossier: Dossier;
}

export function DossierHeader({ initialDossier }: DossierHeaderProps) {
  const [dossier, setDossier] = useState(initialDossier);
  const router = useRouter();

  useEffect(() => {
    setDossier(initialDossier);
  }, [initialDossier]);

  const handleUpdate = (updatedData: Partial<Dossier>) => {
    setDossier((prev) => ({ ...prev, ...updatedData }));
  };

  const handleStatusChange = (newStatus: DossierStatus) => {
    setDossier((prev) => ({ ...prev, status: newStatus }));
  };

  const handleBackToDossiers = () => {
    router.push('/');
    router.refresh();
  };

  return (
    <Card className="mb-8 border-l-4 border-l-blue-600">
      <CardHeader>
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="sm" className="gap-2" onClick={handleBackToDossiers}>
            <ArrowLeft className="h-4 w-4" />
            Retour aux dossiers
          </Button>
          <EditDossierDialog dossier={dossier} onUpdate={handleUpdate} />
        </div>
        <CardTitle className="text-3xl">Dossier Leasing</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <p className="text-sm text-muted-foreground mb-2 font-medium">Statut du dossier</p>
          <DossierStatusSelector
            dossierId={dossier.id}
            currentStatus={dossier.status}
            onStatusChanged={handleStatusChange}
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <User className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-xs text-muted-foreground">Client</p>
              <p className="font-semibold">
                {dossier.first_name} {dossier.last_name}
              </p>
            </div>
          </div>
          {dossier.vehicle_model && (
            <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
              <Car className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-xs text-muted-foreground">Véhicule</p>
                <p className="font-semibold">{dossier.vehicle_model}</p>
              </div>
            </div>
          )}
          {dossier.email && (
            <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
              <Mail className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-xs text-muted-foreground">Email</p>
                <p className="font-semibold text-sm truncate">{dossier.email}</p>
              </div>
            </div>
          )}
          {dossier.phone && (
            <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
              <Phone className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-xs text-muted-foreground">Téléphone</p>
                <p className="font-semibold">{dossier.phone}</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

'use client';

import { useState } from 'react';
import { DossierStatus, STATUS_LABELS, STATUS_COLORS, supabase } from '@/lib/supabase';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface DossierStatusSelectorProps {
  dossierId: string;
  currentStatus: DossierStatus;
  onStatusChanged?: (newStatus: DossierStatus) => void;
}

export function DossierStatusSelector({ dossierId, currentStatus, onStatusChanged }: DossierStatusSelectorProps) {
  const [isPending, setIsPending] = useState(false);
  const [displayStatus, setDisplayStatus] = useState<DossierStatus>(currentStatus);

  const handleStatusChange = async (newStatus: DossierStatus) => {
    setDisplayStatus(newStatus);

    if (onStatusChanged) {
      onStatusChanged(newStatus);
    }

    setIsPending(true);

    try {
      const { error } = await supabase
        .from('dossiers')
        .update({ status: newStatus })
        .eq('id', dossierId);

      if (error) throw error;

      toast.success('Statut mis à jour');
    } catch (error: any) {
      console.error('Failed to update status:', error);
      setDisplayStatus(currentStatus);
      if (onStatusChanged) {
        onStatusChanged(currentStatus);
      }
      toast.error('Erreur lors de la mise à jour du statut');
    } finally {
      setIsPending(false);
    }
  };

  const colors = STATUS_COLORS[displayStatus];

  return (
    <div className="flex items-center gap-2">
      <Select
        value={displayStatus}
        onValueChange={handleStatusChange}
        disabled={isPending}
      >
        <SelectTrigger
          className={`w-full ${colors.bg} ${colors.text} ${colors.border} border-2 font-medium`}
        >
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(STATUS_LABELS).map(([key, label]) => {
            const statusColors = STATUS_COLORS[key as DossierStatus];
            return (
              <SelectItem
                key={key}
                value={key}
                className={`${statusColors.bg} ${statusColors.text} font-medium my-1`}
              >
                {label}
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
      {isPending && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
    </div>
  );
}

/*
  # Reorder Checklist Items

  1. Changes
    - Update the order of checklist items to match the new business process flow
    - Add display_order column to control the order of items
    - Update all checklist item keys and labels to match new order

  2. New Order
    1. Demander documents
    2. Offre de leasing
    3. Lancer identification
    4. Identification terminée
    5. Soumettre la demande
    6. Signature contrat
    7. Envoie QR code
    8. Solder leasing en cours
    9. Achat véhicule
    10. Organiser livraison
    11. Libérer code 178
    12. Immatriculation
    13. Livraison
    14. Signer PV de livraison
    15. Signer contrat de vente
    16. Activer garantie
    17. Activer vignette
    18. Demander avis Google
*/

-- Add display_order column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'checklist_items' AND column_name = 'display_order'
  ) THEN
    ALTER TABLE checklist_items ADD COLUMN display_order INTEGER DEFAULT 0;
  END IF;
END $$;

-- Delete all existing checklist items
DELETE FROM checklist_items;

-- Create a function to insert checklist items for each dossier
CREATE OR REPLACE FUNCTION create_default_checklist_items(p_dossier_id UUID)
RETURNS void AS $$
BEGIN
  INSERT INTO checklist_items (dossier_id, key, label, checked, display_order) VALUES
    (p_dossier_id, 'DEMANDER_DOCS', 'Demander documents', false, 1),
    (p_dossier_id, 'OFFRE_LEASING', 'Offre de leasing', false, 2),
    (p_dossier_id, 'LANCER_IDENTIFICATION', 'Lancer identification', false, 3),
    (p_dossier_id, 'IDENTIFICATION_TERMINEE', 'Identification terminée', false, 4),
    (p_dossier_id, 'SOUMETTRE_DEMANDE', 'Soumettre la demande', false, 5),
    (p_dossier_id, 'SIGNATURE_CONTRAT', 'Signature contrat', false, 6),
    (p_dossier_id, 'ENVOIE_QR_CODE', 'Envoie QR code', false, 7),
    (p_dossier_id, 'SOLDER_LEASING', 'Solder leasing en cours', false, 8),
    (p_dossier_id, 'ACHAT_VEHICULE', 'Achat véhicule', false, 9),
    (p_dossier_id, 'ORGANISER_LIVRAISON', 'Organiser livraison', false, 10),
    (p_dossier_id, 'LIBERER_CODE_178', 'Libérer code 178', false, 11),
    (p_dossier_id, 'IMMATRICULATION', 'Immatriculation', false, 12),
    (p_dossier_id, 'LIVRAISON', 'Livraison', false, 13),
    (p_dossier_id, 'SIGNER_PV_LIVRAISON', 'Signer PV de livraison', false, 14),
    (p_dossier_id, 'SIGNER_CONTRAT_VENTE', 'Signer contrat de vente', false, 15),
    (p_dossier_id, 'ACTIVER_GARANTIE', 'Activer garantie', false, 16),
    (p_dossier_id, 'ACTIVER_VIGNETTE', 'Activer vignette', false, 17),
    (p_dossier_id, 'DEMANDER_AVIS_GOOGLE', 'Demander avis Google', false, 18);
END;
$$ LANGUAGE plpgsql;

-- Insert checklist items for all existing dossiers
DO $$
DECLARE
  dossier_record RECORD;
BEGIN
  FOR dossier_record IN SELECT id FROM dossiers LOOP
    PERFORM create_default_checklist_items(dossier_record.id);
  END LOOP;
END $$;

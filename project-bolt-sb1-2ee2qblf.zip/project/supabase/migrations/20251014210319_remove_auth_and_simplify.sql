/*
  # Simplify Schema - Remove Authentication

  ## Overview
  Remove all authentication and RLS requirements to simplify the application.

  ## Changes
  1. Disable RLS on all tables
  2. Remove all RLS policies
  3. Drop created_by column from dossiers table
  4. Add permissive policies for testing
*/

-- Step 1: Disable RLS on all tables
ALTER TABLE public.dossiers DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.section_notes DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.checklist_items DISABLE ROW LEVEL SECURITY;

-- Step 2: Drop all existing policies
DROP POLICY IF EXISTS "Users can view own dossiers" ON public.dossiers;
DROP POLICY IF EXISTS "Users can create own dossiers" ON public.dossiers;
DROP POLICY IF EXISTS "Users can update own dossiers" ON public.dossiers;
DROP POLICY IF EXISTS "Users can delete own dossiers" ON public.dossiers;
DROP POLICY IF EXISTS "Users can manage notes of own dossiers" ON public.section_notes;
DROP POLICY IF EXISTS "Users can manage documents of own dossiers" ON public.documents;
DROP POLICY IF EXISTS "Users can manage checklist items of own dossiers" ON public.checklist_items;

-- Step 3: Drop the trigger and function
DROP TRIGGER IF EXISTS trg_set_created_by ON public.dossiers;
DROP FUNCTION IF EXISTS public.set_created_by();

-- Step 4: Drop created_by column
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'dossiers'
      AND column_name = 'created_by'
  ) THEN
    ALTER TABLE public.dossiers DROP COLUMN created_by;
  END IF;
END $$;
/*
  # Drop delete_document function

  ## Overview
  Remove the unused RPC function for document deletion.

  ## Changes
  1. Drop the delete_document function - no longer needed
*/

DROP FUNCTION IF EXISTS public.delete_document(uuid);

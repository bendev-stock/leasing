/*
  # Create delete_document RPC function

  ## Overview
  Create a stored procedure to handle document deletion reliably.

  ## Changes
  1. Create delete_document function that deletes a document by ID
  2. Function is accessible to public (no RLS on tables)

  ## Function Details
  - Name: delete_document
  - Parameters: document_id (uuid)
  - Returns: void
  - Purpose: Delete a document record from the documents table
*/

-- Create the delete_document function
CREATE OR REPLACE FUNCTION public.delete_document(document_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM public.documents WHERE id = document_id;
END;
$$;
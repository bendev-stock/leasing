/*
  # Remove "Argent reçu" checklist item

  1. Changes
    - Delete all checklist items with key 'ARGENT_RECU'
    - Update display_order for all checklist items with display_order > 3 to shift them up by 1
    
  2. Notes
    - This reverses the changes made in migration 20251016064026
    - All items after display_order 3 are shifted up to fill the gap
*/

-- Delete all "Argent reçu" checklist items
DELETE FROM checklist_items
WHERE key = 'ARGENT_RECU';

-- Shift down all items that were after "Argent reçu" (display_order > 3)
UPDATE checklist_items
SET display_order = display_order - 1
WHERE display_order > 3;
/*
  # Add category to library documents

  1. Changes
    - Add `category` column to `library_documents` table
    - Category can be: 'Alphera', 'Immatriculation', or 'Contrats internes'
    - Add index for faster category filtering
  
  2. Notes
    - Non-nullable with default value to handle existing records
    - Index added for performance when filtering by category
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'library_documents' AND column_name = 'category'
  ) THEN
    ALTER TABLE library_documents 
    ADD COLUMN category text NOT NULL DEFAULT 'Alphera'
    CHECK (category IN ('Alphera', 'Immatriculation', 'Contrats internes'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_library_documents_category ON library_documents(category);
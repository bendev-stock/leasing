/*
  # Car Republic - Dossier Leasing Schema

  ## Overview
  This migration creates the complete database schema for the Car Republic leasing file management system.
  
  ## New Tables
  
  ### 1. `dossiers`
  Main table storing leasing file information:
  - `id` (uuid, primary key) - Unique identifier for the file
  - `first_name` (text) - Client's first name
  - `last_name` (text) - Client's last name
  - `vehicle_model` (text, nullable) - Vehicle model information
  - `email` (text, nullable) - Client's email address
  - `phone` (text, nullable) - Client's phone number
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### 2. `section_notes`
  Stores notes for each section of a dossier:
  - `id` (uuid, primary key) - Unique identifier
  - `dossier_id` (uuid, foreign key) - References dossiers table
  - `section` (text) - Section type: VEHICULE, PERSONNELLES, CONJOINT, or CONTRACTUELLES
  - `content` (text) - Note content (default empty string)
  - `updated_at` (timestamptz) - Last update timestamp
  - Unique constraint on (dossier_id, section) to ensure one note per section
  
  ### 3. `documents`
  Stores uploaded documents for each section:
  - `id` (uuid, primary key) - Unique identifier
  - `dossier_id` (uuid, foreign key) - References dossiers table
  - `section` (text) - Section where document belongs
  - `name` (text) - File name
  - `url` (text) - Storage URL for the file
  - `mime_type` (text) - File MIME type (PDF, PNG, JPEG)
  - `size_bytes` (integer) - File size in bytes
  - `created_at` (timestamptz) - Upload timestamp
  
  ### 4. `checklist_items`
  Stores checklist items for tracking dossier progress:
  - `id` (uuid, primary key) - Unique identifier
  - `dossier_id` (uuid, foreign key) - References dossiers table
  - `key` (text) - Unique key for the checklist item
  - `label` (text) - Display label in French
  - `checked` (boolean) - Completion status (default false)
  - `updated_at` (timestamptz) - Last update timestamp
  - Unique constraint on (dossier_id, key) to ensure one item per key per dossier
  
  ## Security
  
  - Row Level Security (RLS) enabled on all tables
  - Policies allow authenticated users to manage all records (can be refined later for user-specific access)
  
  ## Notes
  
  1. All foreign keys have CASCADE delete to ensure data integrity
  2. Timestamps use `timestamptz` for timezone-aware dates
  3. Default values provided for boolean and timestamp fields
  4. Unique constraints prevent duplicate notes and checklist items per dossier
*/

-- Create dossiers table
CREATE TABLE IF NOT EXISTS dossiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  vehicle_model text,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create section_notes table
CREATE TABLE IF NOT EXISTS section_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dossier_id uuid NOT NULL REFERENCES dossiers(id) ON DELETE CASCADE,
  section text NOT NULL CHECK (section IN ('VEHICULE', 'PERSONNELLES', 'CONJOINT', 'CONTRACTUELLES')),
  content text DEFAULT '',
  updated_at timestamptz DEFAULT now(),
  UNIQUE(dossier_id, section)
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dossier_id uuid NOT NULL REFERENCES dossiers(id) ON DELETE CASCADE,
  section text NOT NULL CHECK (section IN ('VEHICULE', 'PERSONNELLES', 'CONJOINT', 'CONTRACTUELLES')),
  name text NOT NULL,
  url text NOT NULL,
  mime_type text NOT NULL,
  size_bytes integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create checklist_items table
CREATE TABLE IF NOT EXISTS checklist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dossier_id uuid NOT NULL REFERENCES dossiers(id) ON DELETE CASCADE,
  key text NOT NULL,
  label text NOT NULL,
  checked boolean DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(dossier_id, key)
);

-- Enable Row Level Security
ALTER TABLE dossiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE section_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_items ENABLE ROW LEVEL SECURITY;

-- Policies for dossiers
CREATE POLICY "Allow all operations on dossiers"
  ON dossiers FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for section_notes
CREATE POLICY "Allow all operations on section_notes"
  ON section_notes FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for documents
CREATE POLICY "Allow all operations on documents"
  ON documents FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for checklist_items
CREATE POLICY "Allow all operations on checklist_items"
  ON checklist_items FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_section_notes_dossier_id ON section_notes(dossier_id);
CREATE INDEX IF NOT EXISTS idx_documents_dossier_id ON documents(dossier_id);
CREATE INDEX IF NOT EXISTS idx_checklist_items_dossier_id ON checklist_items(dossier_id);
CREATE INDEX IF NOT EXISTS idx_documents_section ON documents(dossier_id, section);

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers to auto-update updated_at
CREATE TRIGGER update_dossiers_updated_at
  BEFORE UPDATE ON dossiers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_section_notes_updated_at
  BEFORE UPDATE ON section_notes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_checklist_items_updated_at
  BEFORE UPDATE ON checklist_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
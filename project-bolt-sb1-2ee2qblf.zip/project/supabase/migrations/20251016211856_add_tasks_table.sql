/*
  # Create tasks table

  1. New Tables
    - `tasks`
      - `id` (uuid, primary key) - Unique identifier
      - `dossier_id` (uuid, foreign key) - References dossiers table
      - `description` (text) - Task description
      - `completed` (boolean) - Task completion status
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp
  
  2. Security
    - Enable RLS on `tasks` table
    - Add policy for all users to read tasks
    - Add policy for all users to insert tasks
    - Add policy for all users to update tasks
    - Add policy for all users to delete tasks
  
  3. Notes
    - Tasks are tied to dossiers via foreign key with CASCADE delete
    - Completed defaults to false for new tasks
    - Auto-update timestamp on changes
*/

-- Create tasks table
CREATE TABLE IF NOT EXISTS public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dossier_id uuid NOT NULL REFERENCES dossiers(id) ON DELETE CASCADE,
  description text NOT NULL,
  completed boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- Create policies (allowing all operations for all users)
CREATE POLICY "Allow all users to read tasks"
  ON public.tasks FOR SELECT
  USING (true);

CREATE POLICY "Allow all users to insert tasks"
  ON public.tasks FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow all users to update tasks"
  ON public.tasks FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all users to delete tasks"
  ON public.tasks FOR DELETE
  USING (true);

-- Create trigger to auto-update updated_at
CREATE TRIGGER update_tasks_updated_at
  BEFORE UPDATE ON public.tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

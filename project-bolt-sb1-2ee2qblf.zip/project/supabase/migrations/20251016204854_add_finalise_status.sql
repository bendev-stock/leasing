/*
  # Add FINALISE status option

  1. Changes
    - Drop existing status constraint
    - Add new constraint with FINALISE option
    - FINALISE: Finalisé (completed dossier)

  2. Notes
    - Existing dossiers keep their current status
    - New status available for selection
*/

ALTER TABLE dossiers 
DROP CONSTRAINT IF EXISTS dossiers_status_check;

ALTER TABLE dossiers
ADD CONSTRAINT dossiers_status_check 
CHECK (status IN (
  'DOCUMENTS_DEMANDES',
  'DOCUMENTS_RECUS',
  'LEASING_EN_COURS',
  'SOLVABILITE_APPROUVEE',
  'DOSSIER_REFUSE',
  'SANS_SUITE',
  'FINALISE'
));

/*
  # Fix Checklist Order and Duplicates

  1. Changes
    - Delete all duplicate checklist items
    - Recreate with proper display_order
    - Ensure only one set per dossier

  2. Order (by display_order)
    1. Demander documents
    2. Offre de leasing
    3. Lancer identification
    4. Identification terminée
    5. Soumettre la demande
    6. Signature contrat
    7. Envoie QR code
    8. Solder leasing en cours
    9. Achat véhicule
    10. Organiser livraison
    11. Libérer code 178
    12. Immatriculation
    13. Livraison
    14. Signer PV de livraison
    15. Signer contrat de vente
    16. Activer garantie
    17. Activer vignette
    18. Demander avis Google
*/

-- Delete all checklist items
DELETE FROM checklist_items;

-- Recreate with proper order for all dossiers
DO $$
DECLARE
  dossier_record RECORD;
BEGIN
  FOR dossier_record IN SELECT id FROM dossiers LOOP
    INSERT INTO checklist_items (dossier_id, key, label, checked, display_order) VALUES
      (dossier_record.id, 'DEMANDER_DOCS', 'Demander documents', false, 1),
      (dossier_record.id, 'OFFRE_LEASING', 'Offre de leasing', false, 2),
      (dossier_record.id, 'LANCER_IDENTIFICATION', 'Lancer identification', false, 3),
      (dossier_record.id, 'IDENTIFICATION_TERMINEE', 'Identification terminée', false, 4),
      (dossier_record.id, 'SOUMETTRE_DEMANDE', 'Soumettre la demande', false, 5),
      (dossier_record.id, 'SIGNATURE_CONTRAT', 'Signature contrat', false, 6),
      (dossier_record.id, 'ENVOIE_QR_CODE', 'Envoie QR code', false, 7),
      (dossier_record.id, 'SOLDER_LEASING', 'Solder leasing en cours', false, 8),
      (dossier_record.id, 'ACHAT_VEHICULE', 'Achat véhicule', false, 9),
      (dossier_record.id, 'ORGANISER_LIVRAISON', 'Organiser livraison', false, 10),
      (dossier_record.id, 'LIBERER_CODE_178', 'Libérer code 178', false, 11),
      (dossier_record.id, 'IMMATRICULATION', 'Immatriculation', false, 12),
      (dossier_record.id, 'LIVRAISON', 'Livraison', false, 13),
      (dossier_record.id, 'SIGNER_PV_LIVRAISON', 'Signer PV de livraison', false, 14),
      (dossier_record.id, 'SIGNER_CONTRAT_VENTE', 'Signer contrat de vente', false, 15),
      (dossier_record.id, 'ACTIVER_GARANTIE', 'Activer garantie', false, 16),
      (dossier_record.id, 'ACTIVER_VIGNETTE', 'Activer vignette', false, 17),
      (dossier_record.id, 'DEMANDER_AVIS_GOOGLE', 'Demander avis Google', false, 18);
  END LOOP;
END $$;

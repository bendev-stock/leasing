/*
  # Add "Argent reçu" checklist item

  1. Changes
    - Update display_order for all checklist items with display_order >= 3 to make room
    - Insert new checklist items for "Argent reçu" for all existing dossiers
    
  2. Notes
    - The new item is positioned at display_order 3, right after "Offre de leasing" (order 2)
    - All subsequent items are shifted down by 1
*/

-- First, update all existing items with display_order >= 3 to shift them down
UPDATE checklist_items
SET display_order = display_order + 1
WHERE display_order >= 3;

-- Now insert the new "Argent reçu" item for each existing dossier
INSERT INTO checklist_items (dossier_id, key, label, checked, display_order)
SELECT 
  id as dossier_id,
  'ARGENT_RECU' as key,
  'Argent reçu' as label,
  false as checked,
  3 as display_order
FROM dossiers
ON CONFLICT DO NOTHING;
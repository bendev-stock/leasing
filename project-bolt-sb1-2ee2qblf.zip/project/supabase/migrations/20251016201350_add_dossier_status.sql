/*
  # Add status column to dossiers table

  1. Changes
    - Add `status` column to `dossiers` table
      - Type: text with constraint to specific values
      - Default: 'DOCUMENTS_DEMANDES' (Documents demandés)
      - Not null
      - Options:
        - DOCUMENTS_DEMANDES: Documents demandés
        - DOCUMENTS_RECUS: Documents reçus
        - LEASING_EN_COURS: Demande de leasing en cours
        - SOLVABILITE_APPROUVEE: Solvabilité approuvée
        - DOSSIER_REFUSE: Dossier refusé
        - SANS_SUITE: Sans suite

  2. Notes
    - Uses CHECK constraint to enforce valid status values
    - Default status is 'DOCUMENTS_DEMANDES' for new dossiers
    - Existing dossiers will be set to default status
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'dossiers' AND column_name = 'status'
  ) THEN
    ALTER TABLE dossiers 
    ADD COLUMN status text NOT NULL DEFAULT 'DOCUMENTS_DEMANDES'
    CHECK (status IN (
      'DOCUMENTS_DEMANDES',
      'DOCUMENTS_RECUS',
      'LEASING_EN_COURS',
      'SOLVABILITE_APPROUVEE',
      'DOSSIER_REFUSE',
      'SANS_SUITE'
    ));
  END IF;
END $$;
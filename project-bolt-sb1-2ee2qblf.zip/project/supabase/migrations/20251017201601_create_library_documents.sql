/*
  # Create Library Documents System

  1. New Tables
    - `library_documents`
      - `id` (uuid, primary key)
      - `name` (text) - Original filename
      - `url` (text) - Public URL from Supabase Storage
      - `mime_type` (text) - File MIME type
      - `size_bytes` (integer) - File size in bytes
      - `created_at` (timestamptz) - Timestamp of upload
      - `updated_at` (timestamptz) - Auto-updated timestamp

  2. Security
    - Enable RLS on `library_documents` table
    - Add policy allowing anyone to read library documents
    - Add policy allowing anyone to insert library documents
    - Add policy allowing anyone to delete library documents

  3. Storage
    - Create `library` storage bucket for document files
    - Set public access for the bucket
    - Configure storage policies for upload and delete
*/

-- Create library_documents table
CREATE TABLE IF NOT EXISTS library_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text NOT NULL,
  mime_type text NOT NULL,
  size_bytes integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE library_documents ENABLE ROW LEVEL SECURITY;

-- Policies for library_documents (public access for simplicity)
CREATE POLICY "Anyone can read library documents"
  ON library_documents
  FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert library documents"
  ON library_documents
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can delete library documents"
  ON library_documents
  FOR DELETE
  USING (true);

-- Create storage bucket for library documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('library', 'library', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for library bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'objects'
    AND policyname = 'Anyone can upload to library'
  ) THEN
    CREATE POLICY "Anyone can upload to library"
      ON storage.objects
      FOR INSERT
      TO public
      WITH CHECK (bucket_id = 'library');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'objects'
    AND policyname = 'Anyone can read library files'
  ) THEN
    CREATE POLICY "Anyone can read library files"
      ON storage.objects
      FOR SELECT
      TO public
      USING (bucket_id = 'library');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'objects'
    AND policyname = 'Anyone can delete library files'
  ) THEN
    CREATE POLICY "Anyone can delete library files"
      ON storage.objects
      FOR DELETE
      TO public
      USING (bucket_id = 'library');
  END IF;
END $$;
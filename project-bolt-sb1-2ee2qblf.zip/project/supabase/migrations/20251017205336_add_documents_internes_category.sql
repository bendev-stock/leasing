/*
  # Add 'Documents internes' category to library documents

  1. Changes
    - Update check constraint on `category` column to include 'Documents internes'
    - Drop existing constraint and recreate with new values
  
  2. Notes
    - This allows documents to be uploaded with the 'Documents internes' category
    - Existing documents with other categories remain unaffected
*/

DO $$
BEGIN
  -- Drop the existing check constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage
    WHERE table_name = 'library_documents' 
    AND constraint_name = 'library_documents_category_check'
  ) THEN
    ALTER TABLE library_documents DROP CONSTRAINT library_documents_category_check;
  END IF;

  -- Add the new check constraint with the additional category
  ALTER TABLE library_documents 
  ADD CONSTRAINT library_documents_category_check 
  CHECK (category IN ('Alphera', 'Immatriculation', 'Contrats internes', 'Documents internes'));
END $$;

/*
  # Create Storage Bucket for Documents

  ## Overview
  Create a public storage bucket for document uploads with proper configuration.

  ## Changes
  1. Create 'documents' storage bucket
  2. Set bucket as public for easy access
  3. Configure file size limits (50MB)
  4. Add storage policies for public access

  ## Bucket Configuration
  - Name: documents
  - Public: true (for easy document access)
  - File size limit: 50MB
  - Allowed MIME types: PDF, images, documents
*/

-- Create the storage bucket for documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'documents',
  'documents',
  true,
  52428800,
  ARRAY['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow public uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public deletes" ON storage.objects;

-- Create policy to allow anyone to upload files
CREATE POLICY "Allow public uploads"
ON storage.objects
FOR INSERT
TO public
WITH CHECK (bucket_id = 'documents');

-- Create policy to allow anyone to read files
CREATE POLICY "Allow public reads"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'documents');

-- Create policy to allow anyone to delete files
CREATE POLICY "Allow public deletes"
ON storage.objects
FOR DELETE
TO public
USING (bucket_id = 'documents');
/*
  # Add User Ownership and Update RLS Policies

  ## Overview
  This migration adds user ownership tracking and implements proper Row Level Security policies
  to ensure users can only access their own dossiers and related data.

  ## Changes

  ### 1. Schema Updates
  - Add `created_by` column to `dossiers` table (uuid, references auth.users)
  - Add index on `created_by` for performance

  ### 2. RLS Policies
  
  #### Dossiers Table
  - Remove existing permissive policies
  - Add owner-only SELECT policy: users can only view their own dossiers
  - Add owner-only INSERT policy: `created_by` must match authenticated user
  - Add owner-only UPDATE policy: users can only update their own dossiers
  - Add owner-only DELETE policy: users can only delete their own dossiers

  #### Child Tables (section_notes, documents, checklist_items)
  - Replace permissive policies with ownership checks
  - All operations require the parent dossier to belong to the authenticated user
  - Ensures complete data isolation between users

  ### 3. Automation
  - Create trigger function to auto-populate `created_by` on INSERT
  - Trigger ensures `created_by` is always set to current user

  ## Security Notes
  
  1. All policies use `auth.uid()` to identify the current user
  2. Child table policies verify ownership through the parent dossier relationship
  3. Policies are RESTRICTIVE by default - no access without explicit ownership
  4. Both USING and WITH CHECK clauses ensure data integrity on all operations
*/

-- Step 1: Add created_by column to dossiers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'dossiers'
      AND column_name = 'created_by'
  ) THEN
    ALTER TABLE public.dossiers ADD COLUMN created_by uuid;
  END IF;
END $$;

-- Step 2: Create index on created_by for performance
CREATE INDEX IF NOT EXISTS idx_dossiers_created_by ON public.dossiers(created_by);

-- Step 3: Create trigger function to auto-populate created_by
CREATE OR REPLACE FUNCTION public.set_created_by()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.created_by IS NULL THEN
    NEW.created_by := auth.uid();
  END IF;
  RETURN NEW;
END;
$$;

-- Step 4: Create trigger on dossiers table
DROP TRIGGER IF EXISTS trg_set_created_by ON public.dossiers;
CREATE TRIGGER trg_set_created_by
  BEFORE INSERT ON public.dossiers
  FOR EACH ROW
  EXECUTE FUNCTION public.set_created_by();

-- Step 5: Drop existing permissive policies on dossiers
DROP POLICY IF EXISTS "Allow all operations on dossiers" ON public.dossiers;

-- Step 6: Create owner-only policies for dossiers table
CREATE POLICY "Users can view own dossiers"
  ON public.dossiers
  FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

CREATE POLICY "Users can create own dossiers"
  ON public.dossiers
  FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update own dossiers"
  ON public.dossiers
  FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid())
  WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can delete own dossiers"
  ON public.dossiers
  FOR DELETE
  TO authenticated
  USING (created_by = auth.uid());

-- Step 7: Update policies for section_notes (child table)
DROP POLICY IF EXISTS "Allow all operations on section_notes" ON public.section_notes;

CREATE POLICY "Users can manage notes of own dossiers"
  ON public.section_notes
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = section_notes.dossier_id
        AND d.created_by = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = section_notes.dossier_id
        AND d.created_by = auth.uid()
    )
  );

-- Step 8: Update policies for documents (child table)
DROP POLICY IF EXISTS "Allow all operations on documents" ON public.documents;

CREATE POLICY "Users can manage documents of own dossiers"
  ON public.documents
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = documents.dossier_id
        AND d.created_by = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = documents.dossier_id
        AND d.created_by = auth.uid()
    )
  );

-- Step 9: Update policies for checklist_items (child table)
DROP POLICY IF EXISTS "Allow all operations on checklist_items" ON public.checklist_items;

CREATE POLICY "Users can manage checklist items of own dossiers"
  ON public.checklist_items
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = checklist_items.dossier_id
        AND d.created_by = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.dossiers d
      WHERE d.id = checklist_items.dossier_id
        AND d.created_by = auth.uid()
    )
  );
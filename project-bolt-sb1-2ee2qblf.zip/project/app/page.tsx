import { getAllDossiersWithPendingTasks } from '@/lib/actions/dossier';
import { getAllLibraryDocuments } from '@/lib/actions/library';
import { Card, CardContent } from '@/components/ui/card';
import { CreateDossierDialog } from '@/components/create-dossier-dialog';
import { LibraryDialog } from '@/components/library-dialog';
import { DossierList } from '@/components/dossier-list';
import { User } from 'lucide-react';

export const revalidate = 30;

export default async function Home() {
  const [dossiers, libraryDocuments] = await Promise.all([
    getAllDossiersWithPendingTasks(),
    getAllLibraryDocuments(),
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Car Republic</h1>
          <p className="text-muted-foreground">Gestion des dossiers de leasing</p>
        </div>

        <div className="mb-6 flex items-center gap-3">
          <CreateDossierDialog />
          <LibraryDialog initialDocuments={libraryDocuments} />
        </div>

        {dossiers.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <div className="text-muted-foreground">
                <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="text-lg mb-2">Aucun dossier</p>
                <p className="text-sm">Créez votre premier dossier pour commencer</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <DossierList dossiers={dossiers} />
        )}
      </div>
    </div>
  );
}

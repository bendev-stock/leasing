import { getDossier } from '@/lib/actions/dossier';
import { SectionCard } from '@/components/section-card';
import { ChecklistCard } from '@/components/checklist-card';
import { TasksCard } from '@/components/tasks-card';
import { DeleteDossierButton } from '@/components/delete-dossier-button';
import { DossierHeader } from '@/components/dossier-header';
import { notFound } from 'next/navigation';
import { DossierSection } from '@/lib/supabase';

export const revalidate = 30;

interface PageProps {
  params: {
    id: string;
  };
}

export default async function DossierPage({ params }: PageProps) {
  const data = await getDossier(params.id);

  if (!data) {
    notFound();
  }

  const { dossier, notes, documents, checklist, tasks } = data;

  const getNoteContent = (section: DossierSection) => {
    return notes.find((note) => note.section === section)?.content || '';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <DossierHeader initialDossier={dossier} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 space-y-6">
            <SectionCard
              dossierId={params.id}
              section="VEHICULE"
              documents={documents}
              noteContent={getNoteContent('VEHICULE')}
            />
            <SectionCard
              dossierId={params.id}
              section="PERSONNELLES"
              documents={documents}
              noteContent={getNoteContent('PERSONNELLES')}
            />
            <SectionCard
              dossierId={params.id}
              section="CONJOINT"
              documents={documents}
              noteContent={getNoteContent('CONJOINT')}
            />
            <SectionCard
              dossierId={params.id}
              section="CONTRACTUELLES"
              documents={documents}
              noteContent={getNoteContent('CONTRACTUELLES')}
            />
          </div>
          <div>
            <div className="sticky top-8 space-y-6">
              <TasksCard dossierId={params.id} initialTasks={tasks} />
              <ChecklistCard dossierId={params.id} items={checklist} />
            </div>
          </div>
        </div>

        <div className="mt-12 max-w-md mx-auto">
          <DeleteDossierButton
            dossierId={params.id}
            clientName={`${dossier.first_name} ${dossier.last_name}`}
          />
        </div>
      </div>
    </div>
  );
}

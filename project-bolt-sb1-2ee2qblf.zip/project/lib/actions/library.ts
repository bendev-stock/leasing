'use server';

import { createServerSupabaseClient, LibraryDocument } from '@/lib/supabase';

const supabase = createServerSupabaseClient();

export async function getAllLibraryDocuments() {
  const { data: documents, error } = await supabase
    .from('library_documents')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    if (error.message.includes('Could not find the table')) {
      console.warn('Library documents table not yet created. Run migrations.');
      return [];
    }
    throw new Error(`Failed to fetch library documents: ${error.message}`);
  }

  return documents || [];
}

export async function uploadLibraryDocument(formData: FormData) {
  const file = formData.get('file') as File;
  const category = formData.get('category') as string;

  if (!file) {
    throw new Error('Missing file');
  }

  if (!category || !['Alphera', 'Immatriculation', 'Contrats internes', 'Documents internes'].includes(category)) {
    throw new Error('Invalid category');
  }

  const fileExt = file.name.split('.').pop();
  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(7);
  const fileName = `${timestamp}-${randomStr}.${fileExt}`;

  const { data, error: uploadError } = await supabase.storage
    .from('library')
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (uploadError) {
    throw new Error(`Upload failed: ${uploadError.message}`);
  }

  const { data: urlData } = supabase.storage
    .from('library')
    .getPublicUrl(data.path);

  const { data: newDoc, error: insertError } = await supabase
    .from('library_documents')
    .insert({
      name: file.name.normalize('NFC'),
      url: urlData.publicUrl,
      mime_type: file.type,
      size_bytes: file.size,
      category: category,
    })
    .select()
    .single();

  if (insertError) {
    throw new Error(`Failed to add document: ${insertError.message}`);
  }

  return newDoc;
}

export async function deleteLibraryDocument(docId: string) {
  const { error } = await supabase
    .from('library_documents')
    .delete()
    .eq('id', docId);

  if (error) {
    throw new Error(`Failed to delete document: ${error.message}`);
  }

  return { success: true };
}

'use server';

import { createServerSupabaseClient, DossierSection, ChecklistKey, CHECKLIST_ITEMS, DossierStatus } from '@/lib/supabase';
import { revalidatePath } from 'next/cache';

const supabase = createServerSupabaseClient();

export async function getAllDossiers() {
  const { data: dossiers, error } = await supabase
    .from('dossiers')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch dossiers: ${error.message}`);
  }

  return dossiers || [];
}

export async function getAllDossiersWithPendingTasks() {
  const [dossiersResult, tasksResult] = await Promise.all([
    supabase
      .from('dossiers')
      .select('*')
      .order('created_at', { ascending: false }),
    supabase
      .from('tasks')
      .select('*')
      .eq('completed', false)
      .order('created_at', { ascending: false })
  ]);

  if (dossiersResult.error) {
    throw new Error(`Failed to fetch dossiers: ${dossiersResult.error.message}`);
  }

  const dossiers = dossiersResult.data || [];
  const tasks = tasksResult.data || [];

  return dossiers.map(dossier => ({
    ...dossier,
    pendingTasks: tasks.filter(task => task.dossier_id === dossier.id)
  }));
}

export async function getDossier(dossierId: string) {
  const [dossierResult, notesResult, documentsResult, checklistResult, tasksResult] = await Promise.all([
    supabase.from('dossiers').select('*').eq('id', dossierId).maybeSingle(),
    supabase.from('section_notes').select('*').eq('dossier_id', dossierId),
    supabase.from('documents').select('*').eq('dossier_id', dossierId).order('created_at', { ascending: false }),
    supabase.from('checklist_items').select('*').eq('dossier_id', dossierId).order('display_order', { ascending: true }),
    supabase.from('tasks').select('*').eq('dossier_id', dossierId).order('created_at', { ascending: false })
  ]);

  if (dossierResult.error) {
    throw new Error(`Failed to fetch dossier: ${dossierResult.error.message}`);
  }

  if (!dossierResult.data) {
    return null;
  }

  const sections: DossierSection[] = ['VEHICULE', 'PERSONNELLES', 'CONJOINT', 'CONTRACTUELLES'];
  const existingSections = new Set(notesResult.data?.map(n => n.section) || []);
  const existingKeys = new Set(checklistResult.data?.map(c => c.key) || []);

  const missingNotes = sections
    .filter(s => !existingSections.has(s))
    .map(section => ({ dossier_id: dossierId, section, content: '' }));

  const missingChecklist = CHECKLIST_ITEMS
    .filter(item => !existingKeys.has(item.key))
    .map(item => ({ dossier_id: dossierId, key: item.key, label: item.label, checked: false, display_order: item.display_order }));

  if (missingNotes.length > 0 || missingChecklist.length > 0) {
    const promises = [];
    if (missingNotes.length > 0) {
      promises.push(supabase.from('section_notes').insert(missingNotes).select());
    }
    if (missingChecklist.length > 0) {
      promises.push(supabase.from('checklist_items').insert(missingChecklist).select());
    }

    const results = await Promise.all(promises);

    let insertedNotes: any[] = [];
    let insertedChecklist: any[] = [];

    if (missingNotes.length > 0) {
      insertedNotes = results[0]?.data || [];
    }
    if (missingChecklist.length > 0) {
      insertedChecklist = results[missingNotes.length > 0 ? 1 : 0]?.data || [];
    }

    return {
      dossier: dossierResult.data,
      notes: [...(notesResult.data || []), ...insertedNotes],
      documents: documentsResult.data || [],
      checklist: [...(checklistResult.data || []), ...insertedChecklist].sort((a, b) => a.display_order - b.display_order),
      tasks: tasksResult.data || [],
    };
  }

  return {
    dossier: dossierResult.data,
    notes: notesResult.data || [],
    documents: documentsResult.data || [],
    checklist: checklistResult.data || [],
    tasks: tasksResult.data || [],
  };
}

export async function ensureDossierInitialized(dossierId: string) {
  const sections: DossierSection[] = ['VEHICULE', 'PERSONNELLES', 'CONJOINT', 'CONTRACTUELLES'];

  const [existingNotes, existingChecklist] = await Promise.all([
    supabase.from('section_notes').select('section').eq('dossier_id', dossierId),
    supabase.from('checklist_items').select('key').eq('dossier_id', dossierId)
  ]);

  const existingSections = new Set(existingNotes.data?.map(n => n.section) || []);
  const existingKeys = new Set(existingChecklist.data?.map(c => c.key) || []);

  const missingNotes = sections
    .filter(s => !existingSections.has(s))
    .map(section => ({ dossier_id: dossierId, section, content: '' }));

  const missingChecklist = CHECKLIST_ITEMS
    .filter(item => !existingKeys.has(item.key))
    .map(item => ({ dossier_id: dossierId, key: item.key, label: item.label, checked: false, display_order: item.display_order }));

  const promises = [];
  if (missingNotes.length > 0) {
    promises.push(supabase.from('section_notes').insert(missingNotes));
  }
  if (missingChecklist.length > 0) {
    promises.push(supabase.from('checklist_items').insert(missingChecklist));
  }

  if (promises.length > 0) {
    await Promise.all(promises);
  }
}

export async function createDossier(data: {
  firstName: string;
  lastName: string;
  vehicleModel?: string;
  email?: string;
  phone?: string;
}) {
  const { data: dossier, error } = await supabase
    .from('dossiers')
    .insert({
      first_name: data.firstName,
      last_name: data.lastName,
      vehicle_model: data.vehicleModel || null,
      email: data.email || null,
      phone: data.phone || null,
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create dossier: ${error.message}`);
  }

  const sections: DossierSection[] = ['VEHICULE', 'PERSONNELLES', 'CONJOINT', 'CONTRACTUELLES'];

  const notesToInsert = sections.map(section => ({
    dossier_id: dossier.id,
    section,
    content: ''
  }));

  const checklistToInsert = CHECKLIST_ITEMS.map(item => ({
    dossier_id: dossier.id,
    key: item.key,
    label: item.label,
    checked: false,
    display_order: item.display_order
  }));

  await Promise.all([
    supabase.from('section_notes').insert(notesToInsert),
    supabase.from('checklist_items').insert(checklistToInsert)
  ]);

  return dossier;
}

export async function updateDossier(
  dossierId: string,
  data: {
    firstName: string;
    lastName: string;
    vehicleModel?: string;
    email?: string;
    phone?: string;
  }
) {
  const { error } = await supabase
    .from('dossiers')
    .update({
      first_name: data.firstName,
      last_name: data.lastName,
      vehicle_model: data.vehicleModel || null,
      email: data.email || null,
      phone: data.phone || null,
    })
    .eq('id', dossierId);

  if (error) {
    throw new Error(`Failed to update dossier: ${error.message}`);
  }

  revalidatePath(`/dossiers/${dossierId}`);
  revalidatePath('/');

  return { success: true };
}

export async function updateSectionNote(
  dossierId: string,
  section: DossierSection,
  content: string
) {
  const { error } = await supabase
    .from('section_notes')
    .upsert(
      { dossier_id: dossierId, section, content },
      { onConflict: 'dossier_id,section' }
    );

  if (error) {
    throw new Error(`Failed to update note: ${error.message}`);
  }

  return { success: true };
}

export async function uploadDocument(formData: FormData) {
  const file = formData.get('file') as File;
  const dossierId = formData.get('dossierId') as string;
  const section = formData.get('section') as DossierSection;

  if (!file || !dossierId || !section) {
    throw new Error('Missing required fields');
  }

  const fileExt = file.name.split('.').pop();
  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(7);
  const fileName = `${dossierId}/${section}/${timestamp}-${randomStr}.${fileExt}`;

  const { data, error: uploadError } = await supabase.storage
    .from('documents')
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
    });

  if (uploadError) {
    throw new Error(`Upload failed: ${uploadError.message}`);
  }

  const { data: urlData } = supabase.storage
    .from('documents')
    .getPublicUrl(data.path);

  const { data: newDoc, error: insertError } = await supabase.from('documents').insert({
    dossier_id: dossierId,
    section: section,
    name: file.name.normalize('NFC'),
    url: urlData.publicUrl,
    mime_type: file.type,
    size_bytes: file.size,
  }).select().single();

  if (insertError) {
    throw new Error(`Failed to add document: ${insertError.message}`);
  }

  return newDoc;
}


export async function toggleChecklistItem(
  dossierId: string,
  key: ChecklistKey,
  checked: boolean
) {
  const { error } = await supabase
    .from('checklist_items')
    .update({ checked })
    .eq('dossier_id', dossierId)
    .eq('key', key);

  if (error) {
    throw new Error(`Failed to toggle checklist item: ${error.message}`);
  }

  return { success: true };
}

export async function updateDossierStatus(dossierId: string, status: DossierStatus) {
  const { error } = await supabase
    .from('dossiers')
    .update({ status })
    .eq('id', dossierId);

  if (error) {
    throw new Error(`Failed to update status: ${error.message}`);
  }

  revalidatePath(`/dossiers/${dossierId}`);
  revalidatePath('/');

  return { success: true };
}

export async function deleteDossier(dossierId: string) {
  const { data: documents } = await supabase
    .from('documents')
    .select('url')
    .eq('dossier_id', dossierId);

  if (documents && documents.length > 0) {
    for (const doc of documents) {
      const urlPath = doc.url.split('/documents/')[1];
      if (urlPath) {
        await supabase.storage.from('documents').remove([urlPath]);
      }
    }
  }

  const { error } = await supabase.from('dossiers').delete().eq('id', dossierId);

  if (error) {
    throw new Error(`Failed to delete dossier: ${error.message}`);
  }

  revalidatePath('/');

  return { success: true };
}

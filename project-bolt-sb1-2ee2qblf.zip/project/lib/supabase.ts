import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export function createSupabaseClient() {
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false
    }
  });
}

export function createServerSupabaseClient() {
  return createClient(supabaseUrl, supabaseAnonKey);
}

export const supabase = createSupabaseClient();

export type DossierSection = 'VEHICULE' | 'PERSONNELLES' | 'CONJOINT' | 'CONTRACTUELLES';

export type DossierStatus =
  | 'DOCUMENTS_DEMANDES'
  | 'DOCUMENTS_RECUS'
  | 'LEASING_EN_COURS'
  | 'SOLVABILITE_APPROUVEE'
  | 'DOSSIER_REFUSE'
  | 'SANS_SUITE'
  | 'FINALISE';

export type ChecklistKey =
  | 'DEMANDER_DOCS'
  | 'OFFRE_LEASING'
  | 'LANCER_IDENTIFICATION'
  | 'IDENTIFICATION_TERMINEE'
  | 'SOUMETTRE_DEMANDE'
  | 'SIGNATURE_CONTRAT'
  | 'ENVOIE_QR_CODE'
  | 'SOLDER_LEASING'
  | 'ACHAT_VEHICULE'
  | 'ORGANISER_LIVRAISON'
  | 'LIBERER_CODE_178'
  | 'IMMATRICULATION'
  | 'LIVRAISON'
  | 'SIGNER_PV_LIVRAISON'
  | 'SIGNER_CONTRAT_VENTE'
  | 'ACTIVER_GARANTIE'
  | 'ACTIVER_VIGNETTE'
  | 'DEMANDER_AVIS_GOOGLE';

export interface Dossier {
  id: string;
  first_name: string;
  last_name: string;
  vehicle_model: string | null;
  email: string | null;
  phone: string | null;
  status: DossierStatus;
  created_at: string;
  updated_at: string;
}

export interface SectionNote {
  id: string;
  dossier_id: string;
  section: DossierSection;
  content: string;
  updated_at: string;
}

export interface Document {
  id: string;
  dossier_id: string;
  section: DossierSection;
  name: string;
  url: string;
  mime_type: string;
  size_bytes: number;
  created_at: string;
}

export interface ChecklistItem {
  id: string;
  dossier_id: string;
  key: ChecklistKey;
  label: string;
  checked: boolean;
  display_order: number;
  updated_at: string;
}

export interface Task {
  id: string;
  dossier_id: string;
  description: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface LibraryDocument {
  id: string;
  name: string;
  url: string;
  mime_type: string;
  size_bytes: number;
  category: string;
  created_at: string;
  updated_at: string;
}

export const CHECKLIST_ITEMS: { key: ChecklistKey; label: string; display_order: number }[] = [
  { key: 'DEMANDER_DOCS', label: 'Demander documents', display_order: 1 },
  { key: 'OFFRE_LEASING', label: 'Offre de leasing', display_order: 2 },
  { key: 'LANCER_IDENTIFICATION', label: 'Lancer identification', display_order: 3 },
  { key: 'IDENTIFICATION_TERMINEE', label: 'Identification terminée', display_order: 4 },
  { key: 'SOUMETTRE_DEMANDE', label: 'Soumettre la demande', display_order: 5 },
  { key: 'SIGNATURE_CONTRAT', label: 'Signature contrat', display_order: 6 },
  { key: 'ENVOIE_QR_CODE', label: 'Envoie QR code', display_order: 7 },
  { key: 'SOLDER_LEASING', label: 'Solder leasing en cours', display_order: 8 },
  { key: 'ACHAT_VEHICULE', label: 'Achat véhicule', display_order: 9 },
  { key: 'ORGANISER_LIVRAISON', label: 'Organiser livraison', display_order: 10 },
  { key: 'LIBERER_CODE_178', label: 'Libérer code 178', display_order: 11 },
  { key: 'IMMATRICULATION', label: 'Immatriculation', display_order: 12 },
  { key: 'LIVRAISON', label: 'Livraison', display_order: 13 },
  { key: 'SIGNER_PV_LIVRAISON', label: 'Signer PV de livraison', display_order: 14 },
  { key: 'SIGNER_CONTRAT_VENTE', label: 'Signer contrat de vente', display_order: 15 },
  { key: 'ACTIVER_GARANTIE', label: 'Activer garantie', display_order: 16 },
  { key: 'ACTIVER_VIGNETTE', label: 'Activer vignette', display_order: 17 },
  { key: 'DEMANDER_AVIS_GOOGLE', label: 'Demander avis Google', display_order: 18 },
];

export const SECTION_TITLES: Record<DossierSection, string> = {
  VEHICULE: 'Informations véhicule',
  PERSONNELLES: 'Informations personnelles',
  CONJOINT: 'Informations conjoint',
  CONTRACTUELLES: 'Informations contractuelles',
};

export const STATUS_LABELS: Record<DossierStatus, string> = {
  DOCUMENTS_DEMANDES: 'Documents demandés',
  DOCUMENTS_RECUS: 'Documents reçus',
  LEASING_EN_COURS: 'Demande de leasing en cours',
  SOLVABILITE_APPROUVEE: 'Solvabilité approuvée',
  DOSSIER_REFUSE: 'Dossier refusé',
  SANS_SUITE: 'Sans suite',
  FINALISE: 'Finalisé',
};

export const STATUS_COLORS: Record<DossierStatus, { bg: string; text: string; border: string }> = {
  DOCUMENTS_DEMANDES: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  DOCUMENTS_RECUS: { bg: 'bg-cyan-50', text: 'text-cyan-700', border: 'border-cyan-200' },
  LEASING_EN_COURS: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  SOLVABILITE_APPROUVEE: { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
  DOSSIER_REFUSE: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
  SANS_SUITE: { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' },
  FINALISE: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
};
